<h1>Summary</h1>
<p>{{ $generatedText }}</p>