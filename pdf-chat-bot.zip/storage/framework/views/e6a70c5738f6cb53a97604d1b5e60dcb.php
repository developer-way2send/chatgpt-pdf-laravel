<h1>OutPut</h1>
<p><?php echo e($summary); ?></p><?php /**PATH /var/www/html/pdf-text-extraction/resources/views/summary.blade.php ENDPATH**/ ?>